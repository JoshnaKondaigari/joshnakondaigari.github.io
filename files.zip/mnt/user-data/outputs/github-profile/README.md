### Hi, I'm Joshna 👋

**Senior Project & Program Manager** | Agile Delivery • Web Platforms • Pharma & SaaS • AI Automation

I lead cross-functional Engineering, UX, QA, Marketing and Sales teams to ship platforms, launches and regulated content on time. I've spent 12+ years doing this for global SaaS and pharma brands, and I now use Agentic AI to take the busywork out of delivery.

**Recent work**
- Led a 5,000+ page WordPress-to-Sitecore replatform across 4 locales at Seismic
- Launched AI Super Human, an AI chat assistant that contributed to $2M in revenue
- Built Agentic AI workflows that save 4–5 hours per PRD and 5 hours a week on reporting
- Delivered 1,000+ pharma and retail assets through MLR review at 100% SLA compliance

**Find me**
[Portfolio](https://joshnakondaigari.github.io) · [LinkedIn](https://www.linkedin.com/in/joshnareddyk) · [Email](mailto:k_joshna@ymail.com)

📍 Hyderabad, India · Open to program and project leadership roles
